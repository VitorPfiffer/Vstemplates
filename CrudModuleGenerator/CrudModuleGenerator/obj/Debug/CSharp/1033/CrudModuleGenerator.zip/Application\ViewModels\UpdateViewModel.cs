﻿using $ProjectName$.Domain.Enum;

namespace $ProjectName$.Application.ViewModels
{
    public class Update$EntityName$ViewModel
    {

    }
}