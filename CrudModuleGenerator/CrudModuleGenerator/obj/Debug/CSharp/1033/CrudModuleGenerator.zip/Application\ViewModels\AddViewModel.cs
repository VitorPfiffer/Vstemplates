﻿using $ProjectName$.Domain.Enum;

namespace $ProjectName$.Application.ViewModels
{
    public class Add$EntityName$ViewModel
    {

    }
}